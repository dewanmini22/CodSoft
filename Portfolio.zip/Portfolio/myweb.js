function showAlert() {
    alert('Contact me at: dewanmini@example.com');
}
